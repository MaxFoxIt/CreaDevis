<?php
define(
  'QUOTES_PDF_BASE_DIR',
  'C:/Users/max/OneDrive - MTN/Maxime @FoxIT - Private/SARL FOXIT CYBERSECURITY/2. CLIENTS/1. CCTP ou DEVIS/1. Tous les devis'
);
