<?php

return [

  'foxit' => [
    'label' => 'FOXIT',
    'nom' => 'FOXIT',
    'adresse' => "Centre Vaima, 3e étage Bureau 101, BP 41467 Fare Tony, Papeete",
    'telephone' => '87 737 877',
    'email' => 'maxime@foxit-ac.com',
    'siret' => 'N° Tahiti D91679'
],

  'foxit_consulting' => [
    'label' => 'FOXIT CYBERSECURITY',
    'nom' => 'FOXIT CYBERSECURITY',
    'adresse' => "Centre Vaima, 3e étage Bureau 101, BP 41467 Fare Tony, Papeete",
    'telephone' => '87 737 877',
    'email' => 'maxime@foxit-ac.com',
    'siret' => 'N° Tahiti G28799'
  ]

];
