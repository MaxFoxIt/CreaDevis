<?php

return [

  'foxit' => [
    'label' => 'FOXIT',
    'nom' => 'FOXIT',
    'adresse' => "Centre Vaima, 3e étage Bureau 101",
	'BP' => "BP 41467 Fare Tony, Papeete",
    'telephone' => '87 737 877',
    'email' => 'maxime@foxit-ac.com',
	'logo' => 'logo-foxit.png',
    'siret' => 'Numero Tahiti D91679',
	'pdf_dir' => 'C:/Users/max/OneDrive - MTN/Maxime @FoxIT - Private/SARL FOXIT CYBERSECURITY/2. CLIENTS/1. CCTP ou DEVIS/1. Tous les devis/2025/'
],

  'foxit_consulting' => [
    'label' => 'FOXIT CYBERSECURITY',
    'nom' => 'FOXIT CYBERSECURITY',
    'adresse' => "Centre Vaima, 3e étage Bureau 101",
	'BP' => "BP 41467 Fare Tony, Papeete",
    'telephone' => '87 737 877',
    'email' => 'maxime@foxit-ac.com',
	'logo' => 'logo-foxit.png',
    'siret' => 'Numero Tahiti G28799'
  ]

];
