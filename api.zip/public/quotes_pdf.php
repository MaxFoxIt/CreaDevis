<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/fpdf.php';
require_once __DIR__ . '/../includes/config_paths.php';

function pdf_txt(string $s): string {
    return iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $s);
}

$id   = (int)($_GET['id'] ?? 0);
$mode = $_GET['mode'] ?? 'preview'; // preview | save

if ($id <= 0) die("Devis invalide");

/* =========================
   Chargement devis
========================= */
$stmt = $pdo->prepare("SELECT * FROM quotes WHERE id = :id");
$stmt->execute([':id' => $id]);
$quote = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$quote) die("Devis introuvable");

$meta = json_decode($quote['devis_json'], true);
if (!$meta) die("JSON devis invalide");

/* =========================
   Société
========================= */
$companies = require __DIR__ . '/../includes/companies.php';
$company = $companies[$meta['company_key']] ?? null;
if (!$company) die("Société inconnue");

/* =========================
   Lignes
========================= */
$stmt = $pdo->prepare("SELECT * FROM quote_lines WHERE quote_id = :id");
$stmt->execute([':id' => $id]);
$lines = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================
   PDF
========================= */
$pdf = new FPDF();
$pdf->AddPage();

/* Logo */
if (!empty($company['logo'])) {
    $logo = realpath(__DIR__ . '/../assets/' . $company['logo']);
    if ($logo) {
        $pdf->Image($logo, 10, 10, 22);
    }
}

/* Titre */
$pdf->SetFont('Arial','B',16);
$pdf->SetXY(70,15);
$pdf->Cell(0,10,'DEVIS '.$quote['numero_devis'],0,1);
$pdf->Ln(15);

/* Société */
$pdf->SetFont('Arial','B',11);
$pdf->Cell(0,6,pdf_txt($company['nom']),0,1);
$pdf->SetFont('Arial','',10);
$pdf->MultiCell(0,5,pdf_txt(
		trim(
		 ($company['adresse']?? '') . "\n" .
		 ($company['siret']?? '')
		 )));
$pdf->Ln(6);

/* Client */
// --------------------
// Client (robuste)
// --------------------
$client = [
    'nom'     => '',
    'societe' => '',
    'adresse' => '',
    'ref'     => $quote['ref_client'] ?? ''
];

// 1️⃣ Priorité : devis_json
if (!empty($meta['client']) && is_array($meta['client'])) {
    $client = array_merge($client, $meta['client']);
}
// 2️⃣ Fallback : table clients
elseif (!empty($quote['client_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE id = :id");
    $stmt->execute([':id' => $quote['client_id']]);
    if ($c = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $client = [
            'nom'     => $c['nom_client'] ?? '',
            'societe' => $c['societe'] ?? '',
            'adresse' => $c['adresse'] ?? '',
            'ref'     => $c['numero_client'] ?? ($quote['ref_client'] ?? '')
        ];
    }
}
// Position bloc client (DROITE)
$xClient = 120;
$yClient = 55;
$wClient = 70;

$pdf->SetXY($xClient, $yClient);

// Titre
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell($wClient, 6, pdf_txt('Devis pour :'), 0, 1);

// Contenu client
$pdf->SetFont('Arial', '', 10);
$pdf->SetX($xClient);

$pdf->MultiCell(
    $wClient,
    6,
    pdf_txt(
        trim(
            ($client['societe'] ? $client['societe']."\n" : '') .
            ($client['nom'] ? $client['nom']."\n" : '') .
            ($client['adresse'] ? $client['adresse']."\n" : '') .
            ($client['ref'] ? 'Réf : '.$client['ref'] : '')
        )
    ),
    0
);
$pdf->SetY(max($pdf->GetY(), $yClient + 30));
// Infos devis
$pdf->SetFont('Arial', '', 10);
$dateDevis = date('d-m-Y', strtotime($quote['date_devis']));
$dateValidite = date('d-m-Y', strtotime($quote['date_validite']));

$pdf->Cell(0, 6, 'Date du devis : ' . $dateDevis, 0, 1);
$pdf->Cell(0, 6, 'Valable jusqu\'au : ' . $dateValidite, 0, 1);
if (!empty($meta['auteur'])) {
    $pdf->Cell(
        0,
        6,
        'Auteur du devis : ' . pdf_txt($meta['auteur']),
        0,
        1
    );
}
/* Tableau */
$pdf->Ln(10);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(90,7,'Description',1);
$pdf->Cell(20,7,pdf_txt('Quantité'),1,0,'C');
$pdf->Cell(30,7,'PU HT',1,0,'R');
$pdf->Cell(30,7,'Total HT',1,0,'R');
$pdf->Ln();

$pdf->SetFont('Arial','',10);
foreach ($lines as $l) {
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    $pdf->MultiCell(90,6,pdf_txt($l['description']),1);
    $h = $pdf->GetY() - $y;

    $pdf->SetXY($x+90,$y);
    $pdf->Cell(20,$h,$l['quantite'],1,0,'C');
    $pdf->Cell(30,$h,number_format($l['prix_unitaire'],0,'',' '),1,0,'R');
    $pdf->Cell(30,$h,number_format($l['total_ht'],0,'',' '),1,0,'R');
    $pdf->Ln();
}

/* =========================
   TOTAUX
========================= */
$pdf->Ln(5);
$pdf->SetFont('Arial','B',10);

// Total HT
$pdf->Cell(
    0,
    6,
    'Total HT : ' . number_format($quote['prix_remise_ht'], 0, '', ' ') . ' XPF',
    0,
    1
);

// TVA (uniquement si > 0)
$tauxTVA = (float)($quote['taux_tva'] ?? 0);
$montantTVA = (float)($quote['montant_tva'] ?? 0);

if ($tauxTVA > 0 && $montantTVA > 0) {
    $pdf->Cell(
        0,
        6,
        'Montant TVA (' . rtrim(rtrim($tauxTVA, '0'), '.') . ' %) : ' .
        number_format($montantTVA, 0, '', ' ') . ' XPF',
        0,
        1
    );
}

// Total TTC
$pdf->Cell(
    0,
    6,
    'Total TTC : ' . number_format($quote['montant_ttc'], 0, '', ' ') . ' XPF',
    0,
    1
);


/* =========================
   MODE
========================= */
$year    = date('Y', strtotime($quote['date_devis']));
$baseDir = rtrim(QUOTES_PDF_BASE_DIR, '/\\');
$pdfDir  = $baseDir . DIRECTORY_SEPARATOR . $year;
$filename = 'devis_'.$quote['numero_devis'].'.pdf';
$path     = $pdfDir . DIRECTORY_SEPARATOR . $filename;

/* SAVE */
if ($mode === 'save') {

    if (!is_dir($pdfDir)) {
        mkdir($pdfDir, 0775, true);
    }

    $pdf->Output('F', $path);

    // Sauvegarde du chemin en base (optionnel mais recommandé)
    $stmt = $pdo->prepare("UPDATE quotes SET pdf_path = :p WHERE id = :id");
    $stmt->execute([':p' => $path, ':id' => $id]);

    // Retour UX
    header('Location: quotes_list.php');
    exit;
}

/* PREVIEW */
$pdf->Output('I', $filename);
exit;
